#pragma once
#include "Vehicle.h"
#include "Customer.h"
#include "Rental.h"
#include <vector>
#include <deque>
#include <memory>
#include <string>

// RentalSystem owns all vehicles, customers, and rental records.
// std::deque is used for customers_ and rentalHistory_ so that
// emplace_back never invalidates existing pointers/references.
class RentalSystem {
public:
    RentalSystem() = default;

    void addVehicle(std::unique_ptr<Vehicle> vehicle);
    void registerCustomer(int id, const std::string& name);

    bool rentVehicle(int customerId, const std::string& vehicleModel,
                     int days, std::string& errMsg);

    bool returnVehicle(const std::string& vehicleModel, std::string& errMsg);

    void printSummary() const;

private:
    std::vector<std::unique_ptr<Vehicle>> fleet_;
    std::deque<Customer>                  customers_;      // deque: stable addresses
    std::deque<Rental>                    rentalHistory_;  // deque: stable addresses
    int                                   nextRentalId_ = 1;

    Vehicle*  findVehicle(const std::string& model);
    Customer* findCustomer(int id);
};
