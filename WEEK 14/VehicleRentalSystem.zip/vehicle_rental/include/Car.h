#pragma once
#include "Vehicle.h"

// Car is-a Vehicle with a seat count attribute.
class Car : public Vehicle {
public:
    Car(const std::string& model, double dailyRate, int seats);

    double calculateCost(int days) const override;
    std::string getInfo() const override;

    int getSeats() const;

private:
    int seats_;
};
