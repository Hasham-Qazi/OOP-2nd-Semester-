#pragma once
#include <string>

// Abstract base class for all vehicle types.
// Polymorphism is achieved via calculateCost() and getInfo() being pure/virtual.
class Vehicle {
public:
    Vehicle(const std::string& model, double dailyRate);
    virtual ~Vehicle() = default;

    // Pure virtual: each subclass defines its own cost logic
    virtual double calculateCost(int days) const = 0;

    // Virtual: subclasses can add type-specific info lines
    virtual std::string getInfo() const;

    // Accessors
    const std::string& getModel() const;
    double getDailyRate() const;
    bool isAvailable() const;

    void setAvailable(bool status);

protected:
    std::string model_;
    double dailyRate_;
    bool available_;
};
