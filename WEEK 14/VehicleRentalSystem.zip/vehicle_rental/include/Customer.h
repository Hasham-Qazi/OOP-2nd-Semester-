#pragma once
#include <string>

// A registered customer with a unique ID.
// A customer may hold at most one active rental at a time (enforced by RentalSystem).
class Customer {
public:
    Customer(int id, const std::string& name);

    int getId() const;
    const std::string& getName() const;
    bool hasActiveRental() const;
    void setActiveRental(bool status);

private:
    int id_;
    std::string name_;
    bool activeRental_;
};
