#pragma once
#include "Customer.h"
#include "Vehicle.h"
#include <memory>

// Represents a single rental agreement.
// Rental records are never deleted; they are closed on return (active_ = false).
class Rental {
public:
    Rental(int rentalId, Customer* customer, Vehicle* vehicle, int days);

    int getRentalId() const;
    Customer* getCustomer() const;
    Vehicle* getVehicle() const;
    int getDays() const;
    double getTotalCost() const;
    bool isActive() const;

    // Closes the rental (marks vehicle returned, does NOT delete the record)
    void closeRental();

private:
    int rentalId_;
    Customer* customer_;   // non-owning pointer
    Vehicle* vehicle_;     // non-owning pointer
    int days_;
    double totalCost_;
    bool active_;
};
