#pragma once
#include "Vehicle.h"

// Motorbike is-a Vehicle; receives a 10% discount for rentals > 7 days.
class Motorbike : public Vehicle {
public:
    Motorbike(const std::string& model, double dailyRate);

    // Applies 10% long-rental discount when days > 7
    double calculateCost(int days) const override;
    std::string getInfo() const override;
};
