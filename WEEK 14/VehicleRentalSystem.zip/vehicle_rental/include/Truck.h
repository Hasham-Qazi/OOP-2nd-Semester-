#pragma once
#include "Vehicle.h"

// Truck is-a Vehicle with a payload capacity; incurs a 20% surcharge.
class Truck : public Vehicle {
public:
    Truck(const std::string& model, double dailyRate, double payloadTonnes);

    // Applies 20% surcharge on all rentals
    double calculateCost(int days) const override;
    std::string getInfo() const override;

    double getPayload() const;

private:
    double payloadTonnes_;
};
