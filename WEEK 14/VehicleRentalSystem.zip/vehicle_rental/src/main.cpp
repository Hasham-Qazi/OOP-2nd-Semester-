#include <iostream>
#include <memory>
#include "RentalSystem.h"
#include "Car.h"
#include "Motorbike.h"
#include "Truck.h"

int main() {
    RentalSystem system;

    // ── R1: Add fleet (3 vehicle types) ──────────────────────────────────────
    std::cout << "\n=== Adding Vehicles to Fleet ===\n";
    system.addVehicle(std::make_unique<Car>      ("Toyota Camry",   55.00, 5));
    system.addVehicle(std::make_unique<Car>      ("Honda Civic",    45.00, 5));
    system.addVehicle(std::make_unique<Motorbike>("Yamaha MT-07",   30.00));
    system.addVehicle(std::make_unique<Motorbike>("Kawasaki Z650",  28.00));
    system.addVehicle(std::make_unique<Truck>    ("Volvo FH16",    120.00, 20.0));
    std::cout << "  5 vehicles added to the fleet.\n";

    // ── R2: Register customers ────────────────────────────────────────────────
    std::cout << "\n=== Registering Customers ===\n";
    system.registerCustomer(1, "Alice Johnson");
    system.registerCustomer(2, "Bob Martinez");

    // ── R3 & R4: Process rentals ──────────────────────────────────────────────
    std::cout << "\n=== Processing Rentals ===\n";
    std::string err;

    // Alice rents the Camry for 5 days  => $55 * 5 = $275.00
    if (!system.rentVehicle(1, "Toyota Camry", 5, err))
        std::cerr << "  ERROR: " << err << "\n";

    // Bob rents the Motorbike for 10 days => $30 * 10 * 0.90 = $270.00
    if (!system.rentVehicle(2, "Yamaha MT-07", 10, err))
        std::cerr << "  ERROR: " << err << "\n";

    // Attempt to rent an already-rented vehicle (R3 guard)
    std::cout << "\n=== Attempt to Rent Already-Rented Vehicle ===\n";
    if (!system.rentVehicle(1, "Toyota Camry", 3, err))
        std::cout << "  Blocked (expected): " << err << "\n";

    // Attempt to give Alice a second rental (R2 guard)
    std::cout << "\n=== Attempt Second Rental for Same Customer ===\n";
    if (!system.rentVehicle(1, "Honda Civic", 2, err))
        std::cout << "  Blocked (expected): " << err << "\n";

    // ── Truck rental to show surcharge ────────────────────────────────────────
    // Alice must first return her vehicle to rent again later (but for demo
    // we use a fresh customer slot — let's just show truck pricing directly).
    std::cout << "\n=== Truck Rental Demo (20% surcharge) ===\n";
    system.registerCustomer(3, "Carol White");
    if (!system.rentVehicle(3, "Volvo FH16", 3, err))
        std::cerr << "  ERROR: " << err << "\n";
    // Expected: $120 * 3 * 1.20 = $432.00

    // ── R5: Return a vehicle ──────────────────────────────────────────────────
    std::cout << "\n=== Returning a Vehicle ===\n";
    if (!system.returnVehicle("Toyota Camry", err))
        std::cerr << "  ERROR: " << err << "\n";

    // ── R6: Print summary ─────────────────────────────────────────────────────
    system.printSummary();

    return 0;
}
