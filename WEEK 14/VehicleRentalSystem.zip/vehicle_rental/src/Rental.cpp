#include "Rental.h"

Rental::Rental(int rentalId, Customer* customer, Vehicle* vehicle, int days)
    : rentalId_(rentalId)
    , customer_(customer)
    , vehicle_(vehicle)
    , days_(days)
    , totalCost_(vehicle->calculateCost(days))   // polymorphic call
    , active_(true)
{
    // Mark both sides at construction time
    vehicle_->setAvailable(false);
    customer_->setActiveRental(true);
}

int       Rental::getRentalId()   const { return rentalId_; }
Customer* Rental::getCustomer()   const { return customer_; }
Vehicle*  Rental::getVehicle()    const { return vehicle_; }
int       Rental::getDays()       const { return days_; }
double    Rental::getTotalCost()  const { return totalCost_; }
bool      Rental::isActive()      const { return active_; }

void Rental::closeRental() {
    active_ = false;
    vehicle_->setAvailable(true);
    customer_->setActiveRental(false);
}
