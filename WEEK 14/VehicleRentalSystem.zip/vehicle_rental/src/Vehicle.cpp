#include "Vehicle.h"
#include <sstream>
#include <iomanip>

Vehicle::Vehicle(const std::string& model, double dailyRate)
    : model_(model), dailyRate_(dailyRate), available_(true) {}

std::string Vehicle::getInfo() const {
    std::ostringstream oss;
    oss << model_ << " | Rate: $" << std::fixed << std::setprecision(2)
        << dailyRate_ << "/day | " << (available_ ? "Available" : "Rented");
    return oss.str();
}

const std::string& Vehicle::getModel() const { return model_; }
double             Vehicle::getDailyRate()   const { return dailyRate_; }
bool               Vehicle::isAvailable()    const { return available_; }
void               Vehicle::setAvailable(bool s)   { available_ = s; }
