#include "Customer.h"

Customer::Customer(int id, const std::string& name)
    : id_(id), name_(name), activeRental_(false) {}

int                Customer::getId()            const { return id_; }
const std::string& Customer::getName()          const { return name_; }
bool               Customer::hasActiveRental()  const { return activeRental_; }
void               Customer::setActiveRental(bool s)  { activeRental_ = s; }
