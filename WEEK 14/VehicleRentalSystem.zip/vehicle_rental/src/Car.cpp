#include "Car.h"

Car::Car(const std::string& model, double dailyRate, int seats)
    : Vehicle(model, dailyRate), seats_(seats) {}

// Standard pricing — no surcharge or discount applies to cars.
double Car::calculateCost(int days) const {
    return dailyRate_ * days;
}

std::string Car::getInfo() const {
    return "[Car]  " + Vehicle::getInfo() + " | Seats: " + std::to_string(seats_);
}

int Car::getSeats() const { return seats_; }
