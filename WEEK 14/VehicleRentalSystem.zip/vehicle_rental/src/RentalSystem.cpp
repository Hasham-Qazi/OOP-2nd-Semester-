#include "RentalSystem.h"
#include <iostream>
#include <iomanip>
#include <algorithm>

// ── Fleet ────────────────────────────────────────────────────────────────────

void RentalSystem::addVehicle(std::unique_ptr<Vehicle> vehicle) {
    fleet_.push_back(std::move(vehicle));
}

// ── Customers ────────────────────────────────────────────────────────────────

void RentalSystem::registerCustomer(int id, const std::string& name) {
    customers_.emplace_back(id, name);
    std::cout << "  Registered customer: " << name << " (ID " << id << ")\n";
}

// ── Rentals ──────────────────────────────────────────────────────────────────

bool RentalSystem::rentVehicle(int customerId, const std::string& vehicleModel,
                               int days, std::string& errMsg)
{
    Customer* c = findCustomer(customerId);
    if (!c) { errMsg = "Customer ID " + std::to_string(customerId) + " not found."; return false; }
    if (c->hasActiveRental()) { errMsg = c->getName() + " already has an active rental."; return false; }

    Vehicle* v = findVehicle(vehicleModel);
    if (!v) { errMsg = "Vehicle '" + vehicleModel + "' not found."; return false; }
    if (!v->isAvailable()) { errMsg = "Vehicle '" + vehicleModel + "' is already rented."; return false; }

    // Rental constructor performs the polymorphic cost calculation and marks both parties
    rentalHistory_.emplace_back(nextRentalId_++, c, v, days);
    const Rental& r = rentalHistory_.back();
    std::cout << "  Rental #" << r.getRentalId() << " created: "
              << c->getName() << " rents " << v->getModel()
              << " for " << days << " day(s)  => $"
              << std::fixed << std::setprecision(2) << r.getTotalCost() << "\n";
    return true;
}

bool RentalSystem::returnVehicle(const std::string& vehicleModel, std::string& errMsg) {
    for (Rental& r : rentalHistory_) {
        if (r.isActive() && r.getVehicle()->getModel() == vehicleModel) {
            r.closeRental();
            std::cout << "  Returned: " << vehicleModel
                      << " (Rental #" << r.getRentalId() << " closed)\n";
            return true;
        }
    }
    errMsg = "No active rental found for vehicle '" + vehicleModel + "'.";
    return false;
}

// ── Summary ──────────────────────────────────────────────────────────────────

void RentalSystem::printSummary() const {
    std::cout << "\n╔══════════════════════════════════════════════════════╗\n";
    std::cout << "║              RENTAL SYSTEM SUMMARY                  ║\n";
    std::cout << "╚══════════════════════════════════════════════════════╝\n";

    // Active rentals
    std::cout << "\n── Active Rentals ──────────────────────────────────────\n";
    bool anyActive = false;
    for (const Rental& r : rentalHistory_) {
        if (r.isActive()) {
            anyActive = true;
            std::cout << "  Rental #" << r.getRentalId()
                      << " | Customer: " << r.getCustomer()->getName()
                      << " | Vehicle: "  << r.getVehicle()->getModel()
                      << " | Days: "     << r.getDays()
                      << " | Cost: $"    << std::fixed << std::setprecision(2)
                                         << r.getTotalCost() << "\n";
        }
    }
    if (!anyActive) std::cout << "  (none)\n";

    // Closed rentals
    std::cout << "\n── Closed Rentals ──────────────────────────────────────\n";
    bool anyClosed = false;
    for (const Rental& r : rentalHistory_) {
        if (!r.isActive()) {
            anyClosed = true;
            std::cout << "  Rental #" << r.getRentalId()
                      << " [CLOSED] | Customer: " << r.getCustomer()->getName()
                      << " | Vehicle: "            << r.getVehicle()->getModel()
                      << " | Days: "               << r.getDays()
                      << " | Cost: $"              << std::fixed << std::setprecision(2)
                                                   << r.getTotalCost() << "\n";
        }
    }
    if (!anyClosed) std::cout << "  (none)\n";

    // Fleet availability count
    int available = 0, rented = 0;
    for (const auto& v : fleet_) {
        v->isAvailable() ? ++available : ++rented;
    }
    std::cout << "\n── Fleet Status ────────────────────────────────────────\n";
    std::cout << "  Available: " << available << "  |  Rented: " << rented
              << "  |  Total: " << fleet_.size() << "\n";

    // Full fleet list (polymorphic getInfo() call)
    std::cout << "\n── Vehicle Details ─────────────────────────────────────\n";
    for (const auto& v : fleet_) {
        // *** Runtime polymorphism: base pointer calls overridden virtual method ***
        std::cout << "  " << v->getInfo() << "\n";
    }
    std::cout << "\n";
}

// ── Private helpers ──────────────────────────────────────────────────────────

Vehicle* RentalSystem::findVehicle(const std::string& model) {
    for (auto& v : fleet_) {
        if (v->getModel() == model) return v.get();
    }
    return nullptr;
}

Customer* RentalSystem::findCustomer(int id) {
    for (auto& c : customers_) {
        if (c.getId() == id) return &c;
    }
    return nullptr;
}
