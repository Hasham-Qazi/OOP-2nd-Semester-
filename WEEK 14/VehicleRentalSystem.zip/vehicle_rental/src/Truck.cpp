#include "Truck.h"
#include <sstream>
#include <iomanip>

Truck::Truck(const std::string& model, double dailyRate, double payloadTonnes)
    : Vehicle(model, dailyRate), payloadTonnes_(payloadTonnes) {}

double Truck::calculateCost(int days) const {
    return dailyRate_ * days * 1.20;
}

std::string Truck::getInfo() const {
    std::ostringstream oss;
    oss << "[Truck] " << Vehicle::getInfo()
        << " | Payload: " << std::fixed << std::setprecision(1) << payloadTonnes_ << "t"
        << " | +20% surcharge";
    return oss.str();
}

double Truck::getPayload() const { return payloadTonnes_; }
