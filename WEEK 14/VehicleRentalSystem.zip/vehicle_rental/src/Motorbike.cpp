#include "Motorbike.h"

Motorbike::Motorbike(const std::string& model, double dailyRate)
    : Vehicle(model, dailyRate) {}

// Apply 10% discount when rental exceeds 7 days.
double Motorbike::calculateCost(int days) const {
    double cost = dailyRate_ * days;
    if (days > 7) {
        cost *= 0.90;   // 10% long-rental discount
    }
    return cost;
}

std::string Motorbike::getInfo() const {
    return "[Bike] " + Vehicle::getInfo() + " | 10% disc. if >7 days";
}
