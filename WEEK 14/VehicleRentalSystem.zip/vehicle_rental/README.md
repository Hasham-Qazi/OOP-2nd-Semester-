# Vehicle Rental System — OOP with C++

## Overview
A complete C++17 implementation of a vehicle rental management system demonstrating
inheritance, runtime polymorphism, encapsulation, and clean class responsibility separation.

---

## Directory Structure
```
vehicle_rental/
├── include/
│   ├── Vehicle.h          ← Abstract base class
│   ├── Car.h              ← Subclass (seats attribute)
│   ├── Motorbike.h        ← Subclass (10% long-rental discount)
│   ├── Truck.h            ← Subclass (20% surcharge + payload)
│   ├── Customer.h         ← Customer entity
│   ├── Rental.h           ← Rental record
│   └── RentalSystem.h     ← Central coordinator / owner
├── src/
│   ├── Vehicle.cpp
│   ├── Car.cpp
│   ├── Motorbike.cpp
│   ├── Truck.cpp
│   ├── Customer.cpp
│   ├── Rental.cpp
│   ├── RentalSystem.cpp
│   └── main.cpp           ← Full demonstration scenario
├── CMakeLists.txt
├── DESIGN_NOTE.txt        ← Pre-coding design justification (required)
└── README.md
```

---

## How to Build

### Option A — g++ directly
```bash
g++ -std=c++17 -Wall -Wextra -Iinclude \
    src/Vehicle.cpp src/Car.cpp src/Motorbike.cpp src/Truck.cpp \
    src/Customer.cpp src/Rental.cpp src/RentalSystem.cpp src/main.cpp \
    -o rental_system

./rental_system
```

### Option B — CMake
```bash
mkdir build && cd build
cmake ..
make
./rental_system
```

**Requirements:** C++17-compliant compiler (GCC 7+, Clang 5+, MSVC 2017+)

---

## Requirements Satisfied

| # | Requirement              | How it is met                                               |
|---|--------------------------|-------------------------------------------------------------|
| R1 | Fleet management        | `std::vector<unique_ptr<Vehicle>>` holds Car/Motorbike/Truck|
| R2 | Customer registration   | `Customer` class with unique ID; one-rental-at-a-time guard |
| R3 | Process a rental        | `RentalSystem::rentVehicle()` with availability checks      |
| R4 | Calculate cost          | `virtual calculateCost()` per subclass with surcharge/disc. |
| R5 | Return vehicle          | `returnVehicle()` closes rental, marks vehicle available    |
| R6 | Print summary           | `printSummary()` prints active/closed rentals + fleet stats |

---

## Pricing Rules
| Vehicle   | Rule                               | Example                         |
|-----------|------------------------------------|---------------------------------|
| Car       | `dailyRate × days`                 | $55 × 5 = **$275.00**           |
| Motorbike | × 0.90 if days > 7                 | $30 × 10 × 0.90 = **$270.00**   |
| Truck     | `dailyRate × days × 1.20`          | $120 × 3 × 1.20 = **$432.00**   |

---

## Key Design Decisions (see DESIGN_NOTE.txt for full justification)
- **Inheritance** used because Car/Motorbike/Truck satisfy genuine is-a relationships and have distinct pricing behaviour
- **`calculateCost()` is virtual on Vehicle** — pricing belongs to the vehicle, not a utility function
- **`RentalSystem` owns everything** — no cross-pointers between Vehicle/Customer/Rental
- **`std::deque`** used for customers and rentals so that `emplace_back` never invalidates stored raw pointers
- **Runtime polymorphism** occurs at two meaningful points: cost calculation in `Rental` constructor and `getInfo()` in `printSummary()`
